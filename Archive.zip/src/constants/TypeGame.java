package constants;

public class TypeGame {
	
	public static String CAP5x5 = "CAP5x5";
	public static String CoopVsAI = "CoopVsAI";
	public static String CoopVsAI3x3 = "CoopVsAI3x3";
	public static String RankedTeam3x3 = "RankedTeam3x3";
	public static String RankedTeam5x5 = "RankedTeam5x5";
	public static String Unranked3x3 = "Unranked3x3";
	public static String AramUnranked5x5 = "AramUnranked5x5";
	public static String Unranked = "Unranked";
	public static String RankedSolo5x5 = "RankedSolo5x5";
}
