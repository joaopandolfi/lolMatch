package constants;

public class Config {
	public static String LOL_API = "b4547df0-8c17-440f-9d0f-1478ad410680";
}
