package controller;

import model.Message;

import java.util.ArrayList;

/**
 * Created by joao on 6/10/16.
 */
public class ChatControl {

    public ChatControl(){
    }

    public void sendMessageTo(Message message){

    }

    public ArrayList<Message> getMessages(int idReceiver){

        return null;
    }
}
