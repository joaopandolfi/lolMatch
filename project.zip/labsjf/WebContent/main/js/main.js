function label_active(element) {
	element.className = "active";
}